package com.tnsif.pm.college;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementManagementCollegeApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(PlacementManagementCollegeApplication.class, args);
	}

	
}
