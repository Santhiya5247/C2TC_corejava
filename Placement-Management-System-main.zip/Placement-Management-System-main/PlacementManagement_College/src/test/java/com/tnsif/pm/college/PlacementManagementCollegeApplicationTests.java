package com.tnsif.pm.college;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementCollegeApplicationTests {

	@Test
	void contextLoads() {
	}

}
